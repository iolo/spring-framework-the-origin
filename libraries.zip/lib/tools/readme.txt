grinder.jar - The Grinder (2.6.5) used for load testing Java classes

httpunit.jar - HttpUnit used for functional testing of web site
Tidy.jar- required by HttpUnit

junit.jar - JUnit 3.7. Used independently, and also by HttpUnit.