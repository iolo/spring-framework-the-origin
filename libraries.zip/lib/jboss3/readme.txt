Necessary for JBoss connections.

Extracted from /server/deploy/jboss-local-jdbc.rar