Binaries for the Cactus test framework


Need client stuff to run the ServletTestRunner